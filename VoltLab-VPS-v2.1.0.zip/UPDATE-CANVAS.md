# Pembaruan tampilan panel dan login — VoltLab by Febro Herdyanto 2.1.0

Paket ini menambahkan tampilan panel dengan perangkat yang dipasang pada DIN rail, pilihan Panel/Fisik/Skematik, dan menyembunyikan tombol administrator dari halaman login. Login admin lokal tetap dapat dibuka di `/login?admin=1`. Source lengkap menggunakan PM2. Untuk pemasangan baru, ikuti PANDUAN-VPS.md.

Jika sudah dipasang: upload ZIP terbaru ke home Ubuntu melalui WinSCP, lalu jalankan sebagai user PM2 yang sama:

```bash
cd /opt/voltlab
pm2 stop voltlab
unzip -o ~/VoltLab-VPS-v2.1.0.zip -d /opt/voltlab
npm ci
npm run build
pm2 restart voltlab
pm2 save
```

Simpan salinan source/build sebelumnya untuk pemulihan bila build gagal. Arsip tidak memuat .env atau database. Pembaruan tampilan ini tidak membutuhkan migrasi database. Refresh browser setelah update.

Di toolbar Simulator, tombol tampilan berpindah urut dari **Panel** → **Fisik** → **Skematik**. Panel menjadi tampilan default. DIN rail ditambahkan pada komponen modular seperti breaker, contactor/relay, overload, terminal dan power supply. Login utama hanya menunjukkan Google; buka `/login?admin=1` untuk login administrator dengan password lokal. Ilustrasi vektor tersedia di canvas, daftar komponen, Catalog dan Properties. Titik terminal, kabel, rotasi dan perilaku simulasi tetap mengikuti model rangkaian yang sama. Ilustrasi merupakan bentuk perangkat umum, bukan foto atau diagram terminal spesifik merek.
