# Pembaruan komponen fisik — VoltLab by Febro Herdyanto 2.0.2

Paket ini berisi source lengkap untuk PM2. Untuk pemasangan baru, ikuti PANDUAN-VPS.md.

Jika sudah dipasang: upload ZIP terbaru ke home Ubuntu melalui WinSCP, lalu jalankan sebagai user PM2 yang sama:

```bash
cd /opt/voltlab
pm2 stop voltlab
unzip -o ~/VoltLab-VPS-v2.0.zip -d /opt/voltlab
npm ci
npm run build
pm2 restart voltlab
pm2 save
```

Simpan salinan source/build sebelumnya untuk pemulihan bila build gagal. Arsip tidak memuat .env atau database. Pembaruan tampilan ini tidak membutuhkan migrasi database. Refresh browser setelah update.

Di toolbar Simulator terdapat tombol **Fisik**. Klik untuk beralih ke **Skematik**. Mode fisik aktif secara default. Ilustrasi vektor tetap tajam saat zoom dan tersedia di canvas, daftar komponen, Catalog dan Properties. Titik terminal, kabel, rotasi dan perilaku simulasi memakai model yang sama. Ilustrasi merupakan bentuk umum perangkat, bukan diagram terminal spesifik sebuah merek.
