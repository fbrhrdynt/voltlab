export type Model = 'dc'|'ac'|'three'|'switch'|'no'|'nc'|'estop'|'breaker'|'overload'|'coil'|'lamp'|'resistor'|'led'|'motor'|'terminal'|'unsupported';
export type Definition = {id:string;name:string;category:string;model:Model;prefix:string;voltage:number;terminals:string[];description:string;notes:string;mistake:string;resistance?:number;poles?:number;current?:number;dc?:boolean};
const d=(id:string,name:string,category:string,model:Model,prefix:string,voltage:number,terminals:string[],description:string,extra:Partial<Definition>={}):Definition=>({id,name,category,model,prefix,voltage,terminals,description,notes:'Hubungkan setiap kabel ke terminal yang sesuai. Periksa rating sebelum menjalankan rangkaian.',mistake:'Terminal return tidak terhubung, atau rating tegangan tidak sesuai.',...extra});
export const catalog:Definition[]=[
 d('battery','Battery 12 VDC','Sources','dc','BT',12,['+','−'],'Sumber tegangan DC 12 V.',{dc:true}),
 d('supply','Power supply 24 VDC','Sources','dc','PS',24,['+','−'],'Sumber kontrol DC dengan polaritas positif dan return.',{dc:true}),
 d('ac','Source 230 VAC','Sources','ac','AC',230,['L','N','PE'],'Sumber AC satu fase. Tegangan ditampilkan dalam RMS.'),
 d('three','Source 400 VAC · 3φ','Sources','three','AC',400,['L1','L2','L3','N','PE'],'Sumber tiga fase 400 V line-to-line, 50 Hz.'),
 d('fuse','Fuse','Protection','breaker','F',230,['1','2'],'Memutus jalur saat gangguan arus. Trip model ideal.',{poles:1,current:6}),
 d('mcb1','MCB 1 pole','Protection','breaker','QF',230,['1','2'],'Pemutus satu pole dengan reset setelah trip.',{poles:1,current:6}),
 d('mcb2','MCB 2 pole','Protection','breaker','QF',230,['L','N','T','R'],'Memutus live dan neutral bersamaan.',{poles:2,current:10}),
 d('mcb3','MCB 3 pole','Protection','breaker','QF',400,['L1','L2','L3','T1','T2','T3'],'Pemutus tiga fase.',{poles:3,current:16}),
 d('mccb','MCCB 3 pole','Protection','breaker','QF',400,['L1','L2','L3','T1','T2','T3'],'Pemutus daya tiga pole; model switching ideal.',{poles:3,current:40}),
 d('overload','Overload relay','Protection','overload','OL',400,['L1','L2','L3','T1','T2','T3','95','96','97','98'],'Trip membuka 95–96 dan menutup 97–98.',{current:10}),
 d('start','Push button NO','Control','no','PB',24,['13','14'],'Kontak terbuka, menutup hanya saat tombol ditahan.',{notes:'START memakai kontak NO. Lepaskan tombol untuk menguji holding.'}),
 d('stop','Push button NC','Control','nc','PB',24,['21','22'],'Kontak tertutup, membuka saat tombol ditahan.',{notes:'STOP dipasang seri dengan coil dan memakai kontak NC.'}),
 d('estop','Emergency stop','Control','estop','ES',24,['21','22'],'Kontak NC dengan mekanisme latch dan reset.'),
 d('switch','Selector switch','Switching','switch','S',24,['1','2'],'Saklar ON/OFF dengan posisi tetap.'),
 d('relay','Control relay','Control','coil','K',24,['A1','A2','13','14','21','22'],'Coil DC mengendalikan kontak NO dan NC.',{dc:true,resistance:240}),
 d('contactor','Contactor · 3 pole','Switching','coil','K',24,['L1','L2','L3','T1','T2','T3','A1','A2','13','14','21','22'],'Coil 24 VDC mengendalikan tiga kontak utama dan auxiliary.',{dc:true,resistance:240}),
 d('timer','Timer relay','Control','unsupported','KT',24,['A1','A2','15','16','18'],'Relay dengan penundaan waktu. Model timing belum tersedia.'),
 d('lamp12','Lamp 12 VDC','Loads','lamp','H',12,['+','−'],'Lampu resistif 12 V / 3 W.',{dc:true,resistance:48}),
 d('lamp','Lamp 24 VDC','Loads','lamp','H',24,['+','−'],'Lampu resistif 24 V / 6 W.',{dc:true,resistance:96}),
 d('lampac','Lamp 230 VAC','Loads','lamp','H',230,['L','N'],'Lampu resistif AC 230 V / 40 W.',{resistance:1322.5}),
 d('led','LED','Semiconductors','led','D',2,['A','K'],'LED sederhana: Vf 2 V, resistor seri wajib.',{dc:true,resistance:100,notes:'Gunakan resistor seri. Model LED sederhana bukan kurva semikonduktor penuh.'}),
 d('buzzer','Buzzer 24 VDC','Loads','lamp','BZ',24,['+','−'],'Beban buzzer; status aktif ditampilkan tanpa audio.',{dc:true,resistance:240}),
 d('dcmotor','DC motor','Loads','lamp','M',24,['+','−'],'Model beban resistif DC. Tanpa dinamika mekanik.',{dc:true,resistance:24}),
 d('motor1','Single phase motor','Loads','lamp','M',230,['L','N','PE'],'Model beban sederhana motor satu fase.',{resistance:50}),
 d('motor','Three phase motor','Loads','motor','M',400,['U','V','W','PE'],'Motor berjalan saat tiga fase berbeda tersedia. Model logika, tanpa transien.',{current:8}),
 d('solenoid','Solenoid 24 VDC','Loads','lamp','Y',24,['+','−'],'Aktuator DC sebagai beban resistif ideal.',{dc:true,resistance:120}),
 d('resistor','Resistor','Passive Components','resistor','R',0,['1','2'],'Resistor linear untuk rangkaian seri dan paralel.',{resistance:1000}),
 d('capacitor','Capacitor','Passive Components','unsupported','C',50,['1','2'],'Menyimpan energi listrik. Model transien belum tersedia.'),
 d('diode','Diode','Semiconductors','unsupported','D',50,['A','K'],'Komponen searah; model nonlinear belum tersedia.'),
 d('bridge','Bridge rectifier','Semiconductors','unsupported','BR',230,['~1','~2','+','−'],'Penyearah AC; model rectifier belum tersedia.'),
 d('terminal','Terminal block','Distribution','terminal','X',0,['1','2'],'Dua terminal terhubung secara internal.'),
 d('neutral','Neutral bar','Distribution','terminal','XN',0,['N1','N2','N3'],'Bus distribusi neutral.'),
 d('earth','Earth bar','Distribution','terminal','XE',0,['PE1','PE2','PE3'],'Bus protective earth; bukan return sumber DC.'),
 d('cable','Copper cable','Cable','terminal','W',0,['1','2'],'Jalur ideal. Luas penampang tersedia pada properties kabel.'),
 d('meter','Multimeter','Measurement','unsupported','VM',0,['V','COM'],'Gunakan panel multimeter untuk probe pada terminal rangkaian.'),
 d('voltmeter','Voltmeter','Measurement','unsupported','V',0,['V','COM'],'Pengukuran tersedia lewat panel multimeter.'),
 d('ammeter','Ammeter','Measurement','unsupported','A',0,['A','COM'],'Arus beban resistif ditampilkan pada properties; meter seri belum tersedia.'),
 d('continuity','Continuity tester','Measurement','unsupported','CT',0,['1','2'],'Pengujian jalur tersedia lewat multimeter saat STOP.')
];
export const getDef=(id:string)=>catalog.find(d=>d.id===id)!;
export function terminalPosition(d:Definition,index:number){const n=d.terminals.length;return {x:index<Math.ceil(n/2)?0:148,y:35+(index<Math.ceil(n/2)?index:index-Math.ceil(n/2))*27};}
export const componentHeight=(d:Definition)=>Math.max(110,65+Math.ceil(d.terminals.length/2)*27);
