export const courses=[
 {name:'Electrical fundamentals',level:'Dasar',lessons:['Voltage','Current','Resistance','Power','Ohm’s Law','Series circuit','Parallel circuit'],description:'Mulai dari tegangan, arus, dan jalur tertutup.'},
 {name:'DC circuits',level:'Dasar',lessons:['Battery','Switch','LED','Resistor','Relay','Polarity'],description:'Sumber DC, polaritas dan kontrol sederhana.'},
 {name:'AC fundamentals',level:'Dasar',lessons:['Live','Neutral','Earth','Single phase','Three phase','Frequency'],description:'Kenali sumber AC dan hubungan antarfase.'},
 {name:'Protection',level:'Menengah',lessons:['Fuse','MCB','MCCB','Overload','Grounding'],description:'Pelajari fungsi pemutus dan proteksi motor.'},
 {name:'Motor control',level:'Menengah',lessons:['Contactor','Overload','Push button','START / STOP','Self holding','DOL starter'],description:'Dari coil sampai motor starter tiga fase.'},
 {name:'Advanced motor control',level:'Lanjutan',lessons:['Forward / reverse','Electrical interlock','Mechanical interlock','Star delta'],description:'Prinsip arah putaran dan interlock. Simulasi lanjutan belum tersedia.'},
 {name:'Troubleshooting',level:'Menengah',lessons:['Open circuit','Wrong NO / NC','Missing neutral','Coil fault','Overload trip','Phase loss'],description:'Baca diagram, ukur, lalu temukan gangguan.'}
];
export const lessonTexts:Record<string,{text:string;principle:string;question:string;choices:string[];answer:number}>={
 'Voltage':{text:'Tegangan adalah perbedaan potensial antara dua titik. Multimeter mengukur selisih ini, bukan tegangan sebuah terminal tanpa referensi. Pada sumber 24 VDC, probe + dan − menunjukkan 24 V.',principle:'V diukur antara dua terminal.',question:'Bagaimana mengukur tegangan lampu?',choices:['Paralel pada dua terminal lampu','Seri dengan lampu','Hanya pada terminal positif'],answer:0},
 'Current':{text:'Arus hanya mengalir jika rangkaian memiliki jalur lengkap. Pada resistor linear, arus ditentukan oleh tegangan dan resistansi. Memutus saklar membuat jalur terbuka dan arus berhenti.',principle:'I = V / R',question:'24 V pada beban 96 Ω menghasilkan arus berapa?',choices:['4 A','0.25 A','96 A'],answer:1},
 'Resistance':{text:'Resistansi membatasi arus. Untuk resistor ideal, meningkatkan resistansi pada tegangan yang sama menurunkan arus. Nilai aktual komponen dapat berubah karena suhu.',principle:'R = V / I',question:'Jika resistansi dua kali lebih besar pada tegangan tetap?',choices:['Arus dua kali lebih besar','Arus tetap','Arus menjadi setengah'],answer:2},
 'Self holding':{text:'START NO memberi tegangan sementara ke coil. Setelah coil aktif, auxiliary NO 13–14 menutup. Kontak ini dipasang paralel dengan START agar coil tetap aktif setelah START dilepas. STOP NC dipasang seri sebelum kedua jalur.',principle:'START paralel auxiliary; STOP seri coil.',question:'Auxiliary holding dipasang di mana?',choices:['Paralel dengan STOP','Paralel dengan START','Langsung melintasi sumber'],answer:1},
 'DOL starter':{text:'DOL menghubungkan motor langsung ke sumber melalui pemutus, contactor dan overload. Coil mengendalikan kontak utama. Overload 95–96 harus berada pada jalur kontrol agar trip membuat contactor drop.',principle:'Trip OL → 95–96 membuka → coil OFF → motor STOP.',question:'Apa akibat overload 95–96 membuka?',choices:['Coil drop dan motor berhenti','Motor berputar terbalik','Tegangan sumber naik'],answer:0},
 'Contactor':{text:'Contactor mempunyai coil A1–A2, kontak utama L1–T1/L2–T2/L3–T3, serta auxiliary NO 13–14 dan NC 21–22. Saat coil menerima tegangan sesuai rating, kontak utama dan NO menutup; NC membuka.',principle:'Coil dan kontak utama adalah dua bagian listrik berbeda.',question:'Terminal coil contactor adalah?',choices:['L1–T1','13–14','A1–A2'],answer:2},
 'Overload':{text:'Overload melindungi motor dari beban lebih. Dalam model latihan, tombol TRIP mensimulasikan kondisi trip; tidak ada perhitungan kurva termal. Kontak 95–96 membuka sehingga coil dapat drop jika jalur kontrol benar.',principle:'Overload bukan pengganti proteksi hubung singkat.',question:'Kontak NC overload yang dipakai pada kontrol?',choices:['97–98','95–96','L1–T1'],answer:1},
 'Polarity':{text:'DC memiliki polaritas. Lampu resistif mungkin tidak sensitif arah, tetapi LED dan banyak beban elektronik sensitif polaritas. Hubungkan anode/positif ke potensial lebih tinggi dan cathode/negatif ke return.',principle:'Periksa +/− dan A/K.',question:'Polaritas LED yang benar?',choices:['A positif, K negatif','K positif, A negatif','Keduanya ke positif'],answer:0},
 'Three phase':{text:'Sumber tiga fase mempunyai L1, L2, L3 dengan perbedaan sudut 120°. Pada sumber 400 V line-to-line, tegangan phase-to-neutral sekitar 231 V. Motor harus menerima tiga fase berbeda; menyambungkan tiga terminal ke fase sama tidak memberi suplai tiga fase.',principle:'VLL = √3 × VLN',question:'Tegangan phase-to-neutral dari sumber 400 V?',choices:['400 V','Sekitar 231 V','24 V'],answer:1},
 'LED':{text:'LED membutuhkan pembatas arus. Untuk sumber 12 V, LED Vf 2 V dan arus target 20 mA, resistor ideal (12−2)/0.02 = 500 Ω. Pilih nilai standar dan rating daya yang sesuai untuk rangkaian nyata. Model LED VoltLab disederhanakan.',principle:'R = (Vs − Vf) / I',question:'Apakah LED boleh langsung ke sumber 24 V?',choices:['Ya, selalu','Tidak; perlu pembatas arus','Hanya jika kabel panjang'],answer:1},
};
const topics:Record<string,string>={
 'Power':'Daya menyatakan laju transfer energi. Untuk DC, P = V × I. Untuk AC, daya aktif bergantung juga pada power factor. Jangan menyamakan VA dengan W ketika PF kurang dari satu.',
 'Ohm’s Law':'Hukum Ohm menghubungkan tegangan, arus dan resistansi pada elemen linear: V = I × R. Rumus ini tidak otomatis mewakili seluruh perilaku motor atau komponen semikonduktor.',
 'Series circuit':'Dalam rangkaian seri, arus yang sama melewati setiap beban. Resistansi total adalah jumlah resistansi dan tegangan terbagi menurut nilai masing-masing resistor.',
 'Parallel circuit':'Beban paralel menerima tegangan yang sama. Arus cabang dijumlahkan di sumber. Resistansi ekuivalen memenuhi 1/Rtotal = Σ(1/Rn).',
 'Battery':'Baterai adalah sumber DC dengan terminal positif dan negatif. VoltLab menggunakan sumber ideal tanpa resistansi internal atau perubahan kapasitas.',
 'Switch':'Saklar mengubah kontinuitas jalur. ON menutup kontak, OFF membuka. Menutup saklar tidak menjamin beban aktif jika jalur return masih terbuka.',
 'Resistor':'Resistor membatasi arus dan membuang energi sebagai panas. P = I²R membantu memperkirakan rating daya. Model VoltLab menggunakan resistor linear tetap.',
 'Relay':'Relay memisahkan coil kontrol dari kontak. Coil A1–A2 membutuhkan tegangan sesuai rating; NO menutup dan NC membuka saat coil energize.',
 'Live':'Live adalah penghantar aktif pada sumber AC satu fase. Gunakan terminal L dan N sesuai diagram dan fungsi; warna kabel tidak menggantikan identifikasi terminal.',
 'Neutral':'Neutral menyediakan jalur return pada rangkaian satu fase. Neutral dan PE memiliki fungsi berbeda. Beban tidak akan menerima tegangan penuh jika salah satu jalur terbuka.',
 'Earth':'Protective earth digunakan untuk proteksi, bukan sebagai penghantar return normal beban. Simulator dapat memperingatkan PE motor yang belum terhubung.',
 'Single phase':'Sumber satu fase menggunakan L dan N. Untuk daya aktif P = V × I × PF; tegangan AC dinyatakan RMS.',
 'Frequency':'Frekuensi adalah jumlah siklus per detik dalam hertz. Contoh jaringan AC 50 Hz. Engine awal memakai phasor ideal; waveform dan transien belum dihitung.',
 'Fuse':'Fuse memutus jalur ketika kondisi arus tertentu tercapai. Model awal VoltLab menggunakan switching dan trip ideal; tidak merepresentasikan kurva waktu-arus fuse fisik.',
 'MCB':'MCB adalah pemutus dengan proteksi arus lebih dan hubung singkat. Simulator dapat menunjukkan jalur terbuka/tertutup dan trip ideal. Rating nyata harus ditentukan dari instalasi dan standar yang berlaku.',
 'MCCB':'MCCB adalah pemutus daya dengan kemampuan dan pengaturan berbeda menurut model. VoltLab memodelkan kontak tiga pole, bukan kurva trip atau breaking capacity.',
 'Grounding':'Grounding menghubungkan bagian konduktif yang perlu diproteksi ke sistem pembumian. Keberhasilan simulasi tidak memverifikasi efektivitas grounding instalasi nyata.',
 'Push button':'Push button momentary kembali ke kondisi normal saat dilepas. START umumnya NO; STOP umumnya NC. Tahan tombol pada canvas saat RUN untuk menguji.',
 'START / STOP':'STOP NC berada seri pada jalur coil. START NO menutup sesaat untuk mengaktifkan coil. Tanpa auxiliary holding, coil drop saat START dilepas.',
 'Forward / reverse':'Arah motor tiga fase berubah dengan pertukaran dua fase. Dua contactor memerlukan interlock agar tidak aktif bersamaan. Engine awal belum memvalidasi semua konfigurasi forward/reverse.',
 'Electrical interlock':'Kontak NC dari contactor lawan berada seri dengan coil. Tujuannya menghalangi dua arah aktif bersamaan. Implementasi nyata juga memerlukan penilaian proteksi dan keselamatan.',
 'Mechanical interlock':'Interlock mekanik secara fisik mencegah dua contactor menutup bersamaan. Ini berbeda dari interlock listrik. Model mekanik belum tersedia pada engine awal.',
 'Star delta':'Star-delta menurunkan tegangan fase motor saat starting sebelum berpindah ke delta. Memerlukan motor enam terminal, urutan contactor dan timing. Model ini belum tersedia.',
 'Open circuit':'Open circuit berarti jalur listrik terputus. Telusuri sumber, kontak, beban, dan return. Saklar yang sengaja OFF juga menghasilkan jalur terbuka.',
 'Wrong NO / NC':'NO terbuka saat tidak dioperasikan; NC tertutup. Memilih jenis yang salah mengubah perilaku START, STOP dan interlock. Verifikasi terminal dan kondisi normal.',
 'Missing neutral':'Beban satu fase membutuhkan dua titik dengan selisih potensial. Jika neutral hilang, lampu/coil tidak mendapat jalur lengkap. Ukur kedua terminal beban.',
 'Coil fault':'Jika coil tidak energize, ukur A1–A2. Tegangan yang salah, return hilang, atau tipe AC/DC berbeda dapat mencegah operasi. Simulator tidak memodelkan coil terbakar.',
 'Overload trip':'Trip overload membuka 95–96. Periksa apakah kontak itu seri dengan coil. Reset setelah memahami penyebab; trip latihan dilakukan manual.',
 'Phase loss':'Motor tiga fase perlu suplai tiga fase berbeda. Periksa pemutus, tiga kontak utama, overload dan U/V/W untuk menemukan jalur yang terputus.'
};
export function lessonContent(name:string){return lessonTexts[name]||{text:topics[name]||'Periksa fungsi komponen dan terminalnya pada katalog, lalu uji pada simulator.',principle:'Amati perubahan state dan gunakan pengukuran untuk memeriksa rangkaian.',question:'Apa yang perlu diperiksa sebelum menyimpulkan wiring benar?',choices:['Warna kabel saja','Jalur terminal, rating dan hasil pengukuran','Bentuk layout saja'],answer:1};}
export const labs=[
 'Battery switch lamp','Lamps in series','Lamps in parallel','LED and resistor','AC lamp and switch','MCB and lamp','Relay control','Basic contactor coil','START STOP contactor','START STOP holding circuit','DOL motor starter','Emergency stop','Forward reverse motor','Forward reverse interlock','Star delta concept','Find open circuit','Find wrong NO / NC','Find missing neutral','Find phase loss','Find wrong coil voltage'
];
export const challenges=[
 {id:'return',name:'Lampu tidak menyala',description:'Saklar ON, tetapi H1 tetap OFF. Telusuri jalur DC dan perbaiki koneksinya.',template:'dc',hint:'Periksa apakah terminal − lampu memiliki jalur ke − sumber.',rule:'OPEN_CIRCUIT',fault:'Kabel return H1 ke PS1 terputus.'},
 {id:'coil',name:'Contactor tidak menarik',description:'START ditekan, tetapi K1 tidak energize. Periksa rating coil dan suplai.',template:'holding',hint:'Ukur A1–A2 dan bandingkan dengan rating coil pada properties.',rule:'WRONG_COIL_VOLTAGE',fault:'Coil disetel 230 V, sedangkan suplai 24 VDC.'},
 {id:'phase',name:'Motor kehilangan fase',description:'K1 aktif, tetapi M1 tidak berjalan. Periksa jalur daya tiga fase.',template:'dol',hint:'Telusuri OL1:T3 ke M1:W.',rule:'PHASE_LOSS',fault:'Jalur fase ketiga dari overload ke motor terputus.'}
];
