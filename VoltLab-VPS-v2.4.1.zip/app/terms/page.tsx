import LegalDocument from '../../components/LegalDocument';
export default function Terms(){return <LegalDocument kind="terms"/>}
